package com.udea.microserviceregistration;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicroserviceRegistrationApplication {

	public static void main(String[] args) {
		SpringApplication.run(MicroserviceRegistrationApplication.class, args);
	}
}
